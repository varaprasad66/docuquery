# Implementation status — 10 November 2026

Release label: **DEVELOPMENT**. The implementation is locally verified; public demo
and production acceptance are blocked by unconfigured external services.

Branch: `zcode/production-hardening`; base commit `23a6b1539b403f3bffbb3a52335caf83a59b33eb`.
Changes are uncommitted. Existing authentication edits, `.github`, `.zcode`, and the
pre-existing deletion of the empty root package lock were preserved. No push,
publication, client message or paid provisioning occurred.

| Phase | Current result |
|---|---|
| 0 Baseline | PASS locally: unit/integration checks, fresh Alembic rehearsal, Python 3.12 container build and tests. Remote CI has NOT RUN. |
| 1 Privacy/session | Implemented and locally tested: guest isolation, invalid-token rejection, explicit admin provisioning, byte-limited passwords, API scopes, server logout and coordinated refresh. Broad cross-tab race testing remains. |
| 2 Reliability | Implemented: cached history, permission rechecks/invalidation, model/prompt cache fingerprint, atomic chunk replacement, advisory locks, reused worker pools, durable recovery dispatch and cleanup. Concurrent retries/sessions and quota reservations tested. Worker-kill rehearsal and real AI quality BLOCKED. |
| 3 Database | Separate migration URL and bounded pools implemented; fresh local migrations reach 0006. Actual Supabase roles/TLS/exposure verification BLOCKED. |
| 4 Storage | Local and private Supabase adapters, temporary worker files, authorized downloads and durable compensation implemented. Local roundtrip and mocked remote transport tested. Live private bucket tests BLOCKED. |
| 5 Interface | Build and Linux lint PASS; browser upload/chat/mobile/logout smoke PASS using fake AI. Feature flags remove disabled demo surfaces. Full accessibility audit NOT RUN. |
| 6 Deployment | Render Blueprint, images, standalone Compose, health endpoints, account CLI and recovery/rollback runbook prepared. Public hosting, monitoring and backup restoration BLOCKED. |
| 7 Final audit | Local results recorded in verification-results.md; live release gates remain BLOCKED. |
| 8 Portfolio | Truthful portfolio copy, demo script, access guide and 20-case evaluation prepared. Live rehearsal/recording NOT RUN. |

## Decisions

- Keep FastAPI, SQLAlchemy, Alembic, React and existing retrieval; no rewrite.
- Use local JWT authentication. Supabase Auth migration is deferred.
- User delegated hosting choice: prepared Render + Supabase, subject to account setup
  and approval of actual charges. Current Render compute identifiers were checked
  against its documentation; no service purchase was made.
- Hosted demo disables cache, URL import, self-registration and optional integrations.
- Anonymous access is read-only public sample documents. Private conversations,
  uploads, statistics and source downloads require accounts.
- Keep object locators in existing stored_path (`supabase://bucket/owner/id.ext`),
  preserving legacy local locators. Migration 0006 adds durable storage cleanup.
- Document/account row locks reserve uploads/questions before costly work. Worker
  session advisory locks require direct connections or SESSION pooling.
- Three synthetic sessions and concurrent retry tests use a disposable LOCAL test
  database. Hosted databases are never used by the cleanup harness.

See known-limitations.md for outstanding operational and product boundaries.
